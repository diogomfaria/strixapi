package br.com.fiap.strixapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrixApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
